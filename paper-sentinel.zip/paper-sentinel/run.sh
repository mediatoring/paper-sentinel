#!/usr/bin/env sh
set -eu
python -m uvicorn app.main:app --host 127.0.0.1 --port 5792
